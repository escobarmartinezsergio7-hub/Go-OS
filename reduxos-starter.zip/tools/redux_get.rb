#!/usr/bin/env ruby
# frozen_string_literal: true

require "json"
require "fileutils"
require "pathname"

ROOT = Pathname.new(__dir__).parent
REPO_FILE = ROOT.join("tools", "repo.json")
INSTALLED_DIR = ROOT.join("installed_apps")
PACKAGES_DIR = ROOT.join("packages")

cmd = ARGV.shift

if cmd.nil?
  warn "Usage: ruby tools/redux_get.rb <update|search|install|remove|list> [arg]"
  exit 1
end

unless REPO_FILE.file?
  warn "Missing repo file: #{REPO_FILE}"
  exit 1
end

repo = JSON.parse(File.read(REPO_FILE))
apps = repo.fetch("apps")

FileUtils.mkdir_p(INSTALLED_DIR)

case cmd
when "update"
  puts "Repository: #{repo.fetch('name')}"
  puts "Apps available:"
  apps.each do |name, meta|
    puts "- #{name} (#{meta['version']})"
  end
when "search"
  term = (ARGV.shift || "").downcase
  apps.each do |name, meta|
    text = "#{name} #{meta['description']}".downcase
    puts "- #{name} (#{meta['version']})" if text.include?(term)
  end
when "install"
  name = ARGV.shift
  abort "Missing app name" unless name

  meta = apps[name]
  abort "App not found: #{name}" unless meta

  package_path = ROOT.join(meta.fetch("package"))
  abort "Package missing: #{package_path}" unless package_path.file?

  target = INSTALLED_DIR.join(name)
  FileUtils.rm_rf(target)
  FileUtils.mkdir_p(target)

  system("ruby", ROOT.join("tools", "rpx_unpack.rb").to_s, package_path.to_s, target.to_s, exception: true)
  puts "Installed #{name} into #{target}"
when "remove"
  name = ARGV.shift
  abort "Missing app name" unless name

  target = INSTALLED_DIR.join(name)
  if target.exist?
    FileUtils.rm_rf(target)
    puts "Removed #{name}"
  else
    puts "Not installed: #{name}"
  end
when "list"
  dirs = Dir.glob(INSTALLED_DIR.join("*"))
  if dirs.empty?
    puts "No installed apps"
  else
    puts "Installed apps:"
    dirs.each { |d| puts "- #{File.basename(d)}" }
  end
else
  warn "Unknown command: #{cmd}"
  exit 1
end
