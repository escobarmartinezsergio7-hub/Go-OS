#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"
require "pathname"

root = Pathname.new(__dir__).parent
apps_dir = root.join("apps", "hello_redux")
packages_dir = root.join("packages")
package = packages_dir.join("hello_redux.rpx")

FileUtils.mkdir_p(packages_dir)

system("ruby", root.join("tools", "rpx_pack.rb").to_s, apps_dir.to_s, package.to_s, exception: true)
puts "Sample package ready: #{package}"
