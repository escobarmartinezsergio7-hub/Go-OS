#!/usr/bin/env bash
set -euo pipefail

ESP_DIR="${1:-build/esp}"
QEMU_BIN="${QEMU:-qemu-system-x86_64}"
BUILD_DIR="$(cd "${ESP_DIR}"/.. && pwd)"

find_first() {
  for p in "$@"; do
    if [ -f "$p" ]; then
      echo "$p"
      return 0
    fi
  done
  return 1
}

OVMF_CODE="$(find_first \
  /usr/share/OVMF/OVMF_CODE.fd \
  /usr/share/OVMF/OVMF_CODE_4M.fd \
  /usr/share/edk2/ovmf/OVMF_CODE.fd \
  /usr/share/edk2/x64/OVMF_CODE.fd \
  /opt/homebrew/share/qemu/edk2-x86_64-code.fd \
  /usr/local/share/qemu/edk2-x86_64-code.fd \
  2>/dev/null || true)"

OVMF_VARS_TEMPLATE="$(find_first \
  /usr/share/OVMF/OVMF_VARS.fd \
  /usr/share/OVMF/OVMF_VARS_4M.fd \
  /usr/share/edk2/ovmf/OVMF_VARS.fd \
  /usr/share/edk2/x64/OVMF_VARS.fd \
  /opt/homebrew/share/qemu/edk2-x86_64-vars.fd \
  /usr/local/share/qemu/edk2-x86_64-vars.fd \
  2>/dev/null || true)"

if [ -z "${OVMF_CODE}" ] || [ -z "${OVMF_VARS_TEMPLATE}" ]; then
  echo "[error] OVMF firmware not found."
  echo "Install OVMF (Linux) or QEMU with edk2 firmware (macOS Homebrew)."
  exit 1
fi

VARS_FILE="${BUILD_DIR}/OVMF_VARS.fd"
if [ ! -f "${VARS_FILE}" ]; then
  cp "${OVMF_VARS_TEMPLATE}" "${VARS_FILE}"
fi

"${QEMU_BIN}" \
  -machine q35 \
  -m 1024 \
  -drive "if=pflash,format=raw,readonly=on,file=${OVMF_CODE}" \
  -drive "if=pflash,format=raw,file=${VARS_FILE}" \
  -drive "format=raw,file=fat:rw:${ESP_DIR}" \
  -serial stdio
