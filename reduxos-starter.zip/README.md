# ReduxOS Starter (Rust + C++ + Ruby)

Starter de SO experimental con dos rutas:

- **UEFI x86_64 (principal):** Rust `no_std` sobre `x86_64-unknown-uefi` + QEMU/OVMF

## Estado actual

Este repo ahora esta ajustado para **x86_64 + UEFI (OVMF)** como camino principal de prueba.

## Estructura clave

- `kernel/src/main.rs`: app UEFI en Rust (entry EFI)
- `scripts/run_uefi.sh`: runner QEMU + deteccion OVMF
- `Makefile`: targets UEFI por defecto
- `Makefile.legacy-bios`: snapshot historico BIOS/multiboot (referencia)
- `kernel/src/legacy_bios.rs`: shell legacy BIOS (referencia historica)
- `tools/`: empaquetador/instalador `.rpx` (Ruby)
- `apps/hello_redux/`: app de ejemplo (`.rml` + `.rdx`)
- `sdk/reduxlang/`: lexer+parser+evaluator ejecutable

## Dependencias UEFI (principal)

- `rustup`
- target Rust: `x86_64-unknown-uefi`
- `qemu-system-x86_64`
- firmware OVMF/edk2
- `ruby` (para herramientas de paquetes)

## Build UEFI

```bash
rustup target add x86_64-unknown-uefi
make clean
make uefi
```

Esto genera:

- `build/esp/EFI/BOOT/BOOTX64.EFI`

## Ejecutar en QEMU + OVMF

```bash
make run
```

El script `scripts/run_uefi.sh` detecta OVMF en rutas comunes de Linux/macOS.

## Paquetes `.rpx` (Ruby)

Generar paquete de ejemplo:

```bash
ruby tools/bootstrap_repo.rb
```

Actualizar catalogo:

```bash
ruby tools/redux_get.rb update
```

Instalar app local:

```bash
ruby tools/redux_get.rb install hello-redux
```

Listar instaladas:

```bash
ruby tools/redux_get.rb list
```

## SDK ReduxLang

```bash
cargo run --manifest-path sdk/reduxlang/Cargo.toml
```

Ejemplo en REPL:

```text
let x = 7 * (3 + 2);
x + 10;
```
