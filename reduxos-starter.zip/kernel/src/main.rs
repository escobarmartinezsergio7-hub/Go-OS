#![no_std]
#![no_main]

use core::fmt::Write;
use core::panic::PanicInfo;

use uefi::prelude::*;
use uefi::table::runtime::ResetType;

#[entry]
fn efi_main(_image_handle: Handle, mut st: SystemTable<Boot>) -> Status {
    {
        let out = st.stdout();
        let _ = out.reset(false);
        let _ = out.clear();
        let _ = writeln!(out, "ReduxOS UEFI Starter");
        let _ = writeln!(out, "Mode: x86_64 + OVMF");
        let _ = writeln!(out, "Kernel stack: Rust no_std");
        let _ = writeln!(out, "");
        let _ = writeln!(out, "What this validates:");
        let _ = writeln!(out, "- UEFI boot path works");
        let _ = writeln!(out, "- EFI image packaging works");
        let _ = writeln!(out, "- QEMU+OVMF test loop works");
        let _ = writeln!(out, "");
        let _ = writeln!(out, "Press any key to reboot...");
    }

    loop {
        if st.stdin().read_key().ok().flatten().is_some() {
            let _ = writeln!(st.stdout(), "Rebooting from UEFI app...");
            st.runtime_services()
                .reset(ResetType::Cold, Status::SUCCESS, None);
        }

        st.boot_services().stall(20_000);
    }
}

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {
        core::hint::spin_loop();
    }
}
